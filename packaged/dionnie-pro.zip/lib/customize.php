<?php




require_once('customize_helpers.php');


function dionnie_pro_customize_register($wp_customize)
{

    /*---------------------------------------------------------------------------
* Start of General Options
*---------------------------------------------------------------------------*/
    $wp_customize->add_section('dionnie_pro_general_options', array(
        'title' => esc_html__('General Options', 'dionnie-pro'),
        'description' => esc_html__('You can change general options from here.', 'dionnie-pro')
    ));
    /*---------------------------------------------------------------------------
* Accent Color
*---------------------------------------------------------------------------*/
    $wp_customize->add_setting('dionnie_pro_accent_colour', array(
        'default' => '#20ddae',
        'transport' => 'postMessage',
        'sanitize_callback' => 'sanitize_hex_color'
    ));

    $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'dionnie_pro_accent_colour', array(
        'label' => __('Accent Color', 'dionnie-pro'),
        'section' => 'dionnie_pro_general_options',
    )));
    /*---------------------------------------------------------------------------
* Portfolio Slug
*---------------------------------------------------------------------------*/

    $wp_customize->add_setting('dionnie_pro_portfolio_slug', array(
        'default'           => 'portfolio',
        'transport'         => 'postMessage',
        'sanitize_callback' => 'sanitize_text_field',
    ));

    $wp_customize->add_control('dionnie_pro_portfolio_slug', array(
        'type'    => 'text',
        'label'    => esc_html__('Portfolio Slug', 'dionnie-pro'),
        'description' => esc_html__('Will appear in the archive url', 'dionnie-pro'),
        'section'  => 'dionnie_pro_general_options',
    ));

    /*---------------------------------------------------------------------------
* End of General Options
*---------------------------------------------------------------------------*/



    /*---------------------------------------------------------------------------
* Start of Footer Options
*---------------------------------------------------------------------------*/

    $wp_customize->add_setting('nav_menus', array(
        'selector' => '.header-nav ',
        'container_inclusive' => false,
    ));

    $wp_customize->selective_refresh->add_partial('dionnie_pro_footer_partial', array(
        'settings' => array('dionnie_pro_footer_bg', 'dionnie_pro_footer_layout'),
        'selector' => '#footer',
        'container_inclusive' => false,
        'render_callback' => function () {
            get_template_part('template-parts/footer/widgets');
            get_template_part('template-parts/footer/info');
        }
    ));

    $wp_customize->add_section('dionnie_pro_footer_options', array(
        'title' => esc_html__('Footer Options', 'dionnie-pro'),
        'description' => esc_html__('You can change footer options from here.', 'dionnie-pro')
    ));

    /*---------------------------------------------------------------------------
* Site Info
*---------------------------------------------------------------------------*/

    $wp_customize->add_setting('dionnie_pro_site_info', array(
        'default' => '',
        'sanitize_callback' => 'dionnie_pro_sanitize_site_info',
        'transport' => 'postMessage'
    ));

    $wp_customize->add_control('dionnie_pro_site_info', array(
        'type' => 'text',
        'label' => esc_html__('Site Info', 'dionnie-pro'),
        'section' => 'dionnie_pro_footer_options'
    ));




    /*---------------------------------------------------------------------------
* Footer Background
*---------------------------------------------------------------------------*/
    $wp_customize->add_setting('dionnie_pro_footer_bg', array(
        'default' => 'dark',
        'transport' => 'postMessage',
        'sanitize_callback' => 'dionnie_pro_sanitize_footer_bg'
    ));

    $wp_customize->add_control('dionnie_pro_footer_bg', array(
        'type' => 'select',
        'label' => esc_html__('Footer Background', 'dionnie-pro'),
        'choices' => array(
            'light' => esc_html__('Light', 'dionnie-pro'),
            'dark' => esc_html__('Dark', 'dionnie-pro'),
        ),
        'section' => 'dionnie_pro_footer_options'
    ));








    /*---------------------------------------------------------------------------
* Footer Layout
*---------------------------------------------------------------------------*/
    $wp_customize->add_setting('dionnie_pro_footer_layout', array(
        'default' => '3,3,3,3',
        'transport' => 'postMessage',
        'sanitize_callback' => 'sanitize_text_field',
        'validate_callback' => 'dionnie_pro_validate_footer_layout'
    ));

    $wp_customize->add_control('dionnie_pro_footer_layout', array(
        'type' => 'text',
        'label' => esc_html__('Footer Layout', 'dionnie-pro'),
        'section' => 'dionnie_pro_footer_options'
    ));


    /*---------------------------------------------------------------------------
* End of Footer Options
*---------------------------------------------------------------------------*/



    $wp_customize->get_setting('blogname')->transport = 'postMessage';

    $wp_customize->selective_refresh->add_partial('blogname_partial', array(
        'settings' => array('blogname'),
        'selector' => '.c-header__blogname',
        'container_inclusive' => true,
        'render_callback' => function () {
            bloginfo('name');
        }
    ));

    /*##################  SINGLE SETTINGS ########################*/

    $wp_customize->add_section('dionnie_pro_single_blog_options', array(
        'title' => esc_html__('Single Blog Options', 'dionnie-pro'),
        'description' => esc_html__('You can change single blog options from here.', 'dionnie-pro'),
        'active_callback' => 'dionnie_pro_show_single_blog_section'
    ));

    $wp_customize->add_setting('dionnie_pro_display_author_info', array(
        'default' => true,
        'transport' => 'postMessage',
        'sanitize_callback' => 'dionnie_pro_sanitize_checkbox'
    ));

    $wp_customize->add_control('dionnie_pro_display_author_info', array(
        'type' => 'checkbox',
        'label' => esc_html__('Show Author Info', 'dionnie-pro'),
        'section' => 'dionnie_pro_single_blog_options'
    ));



    function dionnie_pro_show_single_blog_section()
    {
        global $post;
        return is_single() && $post->post_type === 'post';
    }
}


add_action('customize_register', 'dionnie_pro_customize_register');
