<?php

require_once('class-tgm-plugin-activation.php');

add_action('tgmpa_register', 'dionnie_pro_register_required_plugins');

function dionnie_pro_register_required_plugins()
{
    $plugins = array(
        array(
            'name' => 'Dionnie WP',
            'slug' => 'dionnie-wp',
            'source' => 'plugins/dionnie-wp.zip',
            'required' => true,
            'version' => '1.0.0',
            'force_activation' => false,
            'force_deactivation' => false,
        ),
        /*   array(
            'name' => 'dionnie-pro shortcodes',
            'slug' => 'dionnie-pro-shortcodes',
            'source' => get_template_directory_uri() . '/lib/plugins/dionnie-pro-shortcodes.zip',
            'required' => true,
            'version' => '1.0.0',
            'force_activation' => false,
            'force_deactivation' => false,
        ),
        array(
            'name' => 'dionnie-pro post types',
            'slug' => 'dionnie-pro-post-types',
            'source' => get_template_directory_uri() . '/lib/plugins/dionnie-pro-post-types.zip',
            'required' => true,
            'version' => '1.0.0',
            'force_activation' => false,
            'force_deactivation' => false,
        ) */
    );

    $config = array();

    tgmpa($plugins, $config);
}
