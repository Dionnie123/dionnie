<div class="card p-3">
    <aside role="complementary">

        <?php dynamic_sidebar('primary-sidebar'); ?>

    </aside>
</div>