<?php

/**
 * Plugin Name: dionnie dionnie_essentials
 * Description: Essential plugin for Dionnie Theme.
 * Version: 1.0
 * Author: Mark Dionnie Bulingit
 * License: GPL2 
 * Licese URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: dionnie-dionnie_essentials
 * Domain Path: /languages
 */

if (!defined('WPINC')) {
    die;
}
include_once('dist/lib/helpers.php');
include_once('dist/lib/enqueue-assets.php');
include_once('dist/lib/books.php');
