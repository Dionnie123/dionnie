<?php


require_once(get_template_directory() . '/dist/lib/helpers.php');
require_once(get_template_directory() . '/dist/lib/enqueue-assets.php');
