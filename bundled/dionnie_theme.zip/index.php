<?php

get_header();
get_template_part('posts-template');
//get_template_part('1-loops');
get_footer();