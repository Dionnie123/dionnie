<?php

get_header();


get_template_part('template-parts/post/grid');

get_footer();
