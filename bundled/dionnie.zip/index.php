<?php

get_header();


get_template_part('template-parts/post/loop');

get_footer();
